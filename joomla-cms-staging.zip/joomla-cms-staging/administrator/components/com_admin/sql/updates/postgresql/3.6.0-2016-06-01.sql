UPDATE "#__extensions" SET "protected" = 1, "enabled" = 1 WHERE "name" = 'com_ajax';
